package com.banking;
import java.util.*;

public class BankingSystemApp {
	  public static void main(String[] args) {

	        Scanner sc = new Scanner(System.in);
	        BankingService service = new BankingServiceImpl();

	        while (true) {

	            System.out.println("\nBanking System");
	            System.out.println("1. Add Customer");
	            System.out.println("2. Add Account");
	            System.out.println("3. Add Beneficiary");
	            System.out.println("4. Add Transaction");
	            System.out.println("5. Find Customer by Id");
	            System.out.println("6. List all Accounts of specific Customer");
	            System.out.println("7. List all transactions of specific Account");
	            System.out.println("8. List all beneficiaries of specific customer");
	            System.out.println("9. Exit");

	            System.out.print("Enter your choice: ");
	            int choice = sc.nextInt();

	            switch (choice) {

	                case 1:
	                    System.out.println("Enter Customer Details");
	                    System.out.print("Customer Id: ");
	                    int cid = sc.nextInt();
	                    sc.nextLine();
	                    System.out.print("Name: ");
	                    String cname = sc.nextLine();
	                    System.out.print("Address: ");
	                    String addr = sc.nextLine();
	                    System.out.print("Contact No: ");
	                    String contact = sc.nextLine();

	                    service.addCustomer(new Customer(cid, cname, addr, contact));
	                    break;

	                case 2:
	                    System.out.println("Enter Account Details");
	                    System.out.print("Account Id: ");
	                    int aid = sc.nextInt();
	                    System.out.print("Customer Id: ");
	                    int cida = sc.nextInt();
	                    sc.nextLine();
	                    System.out.print("Account Type (Saving/Current): ");
	                    String type = sc.nextLine();
	                    System.out.print("Balance: ");
	                    double bal = sc.nextDouble();

	                    service.addAccount(new Account(aid, cida, type, bal));
	                    break;

	                case 3:
	                    System.out.println("Enter Beneficiary Details");
	                    System.out.print("Beneficiary Id: ");
	                    int bid = sc.nextInt();
	                    System.out.print("Customer Id: ");
	                    int bcust = sc.nextInt();
	                    sc.nextLine();
	                    System.out.print("Beneficiary Name: ");
	                    String bname = sc.nextLine();
	                    System.out.print("Beneficiary Account No: ");
	                    String bacc = sc.nextLine();
	                    System.out.print("Bank Details: ");
	                    String bbank = sc.nextLine();

	                    service.addBeneficiary(
	                            new Beneficiary(bid, bcust, bname, bacc, bbank)
	                    );
	                    break;

	                case 4:
	                    System.out.println("Enter Transaction Details");
	                    System.out.print("Account Id: ");
	                    int taid = sc.nextInt();
	                    sc.nextLine();
	                    System.out.print("Type (Deposit/Withdrawal): ");
	                    String ttype = sc.nextLine();
	                    System.out.print("Amount: ");
	                    double amt = sc.nextDouble();

	                    service.addTransaction(new Transaction(taid, ttype, amt));
	                    break;

	                case 5:
	                    System.out.print("Enter Customer Id: ");
	                    int findid = sc.nextInt();
	                    Customer cust = service.findCustomerById(findid);
	                    System.out.println(cust != null ? cust : "Customer Not Found!");
	                    break;

	                case 6:
	                    System.out.print("Customer Id: ");
	                    int accCusId = sc.nextInt();
	                    List<Account> accs = service.getAccountsByCustomerId(accCusId);
	                    System.out.println("Accounts:");
	                    accs.forEach(System.out::println);
	                    break;

	                case 7:
	                    System.out.print("Account Id: ");
	                    int tracc = sc.nextInt();
	                    List<Transaction> trs = service.getTransactionsByAccountId(tracc);
	                    System.out.println("Transactions:");
	                    trs.forEach(System.out::println);
	                    break;

	                case 8:
	                    System.out.print("Customer Id: ");
	                    int benid = sc.nextInt();
	                    List<Beneficiary> bens = service.getBeneficiariesByCustomerId(benid);
	                    System.out.println("Beneficiaries:");
	                    bens.forEach(System.out::println);
	                    break;

	                case 9:
	                    System.out.println("Thank you!");
	                    System.exit(0);

	                default:
	                    System.out.println("Invalid Choice!");
	            }
	        }
	    }

}
