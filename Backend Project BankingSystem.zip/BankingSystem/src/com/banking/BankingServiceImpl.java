package com.banking;

import java.sql.*;
import java.util.*;

public class BankingServiceImpl implements BankingService {

    // ----------------------------------------
    // ADD CUSTOMER
    // ----------------------------------------
    @Override
    public void addCustomer(Customer c) {
        String sql = "INSERT INTO customers VALUES (?, ?, ?, ?)";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, c.getCustomerID());
            ps.setString(2, c.getName());
            ps.setString(3, c.getAddress());
            ps.setString(4, c.getContact());

            ps.executeUpdate();
            System.out.println("✅ Customer added!");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ----------------------------------------
    // ADD ACCOUNT
    // ----------------------------------------
    @Override
    public void addAccount(Account a) {
        String sql = "INSERT INTO accounts VALUES (?, ?, ?, ?)";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, a.getAccountID());
            ps.setInt(2, a.getCustomerID());
            ps.setString(3, a.getType());
            ps.setDouble(4, a.getBalance());

            ps.executeUpdate();
            System.out.println("✅ Account added!");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ----------------------------------------
    // ADD BENEFICIARY
    // ----------------------------------------
    @Override
    public void addBeneficiary(Beneficiary b) {
        String sql = "INSERT INTO beneficiaries VALUES (?, ?, ?, ?, ?)";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, b.getBeneficiaryID());
            ps.setInt(2, b.getCustomerID());
            ps.setString(3, b.getName());
            ps.setString(4, b.getAccountNumber());
            ps.setString(5, b.getBankDetails());

            ps.executeUpdate();
            System.out.println("✅ Beneficiary added!");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ----------------------------------------
    // ADD TRANSACTION + UPDATE BALANCE
    // ----------------------------------------
    @Override
    public void addTransaction(Transaction t) {

        String insert =
            "INSERT INTO transactions (accountID, type, amount, timestamp) VALUES (?, ?, ?, ?)";

        String deposit =
            "UPDATE accounts SET balance = balance + ? WHERE accountID = ?";

        String withdraw =
            "UPDATE accounts SET balance = balance - ? WHERE accountID = ?";

        try (Connection con = DatabaseConnection.getConnection()) {

            // 1️⃣ Insert transaction
            PreparedStatement ps1 = con.prepareStatement(insert, Statement.RETURN_GENERATED_KEYS);
            ps1.setInt(1, t.getAccountID());
            ps1.setString(2, t.getType());
            ps1.setDouble(3, t.getAmount());
            ps1.setTimestamp(4, Timestamp.valueOf(t.getTimestamp()));
            ps1.executeUpdate();

            ResultSet rs = ps1.getGeneratedKeys();
            if (rs.next()) t.setTransactionID(rs.getInt(1));

            // 2️⃣ Update account balance
            PreparedStatement ps2;
            String type = t.getType().toLowerCase();

            if (type.contains("dep")) {
                ps2 = con.prepareStatement(deposit);
                System.out.println("💰 Deposit Successful!");
            } else {
                ps2 = con.prepareStatement(withdraw);
                System.out.println("💵 Withdrawal Successful!");
            }

            ps2.setDouble(1, t.getAmount());
            ps2.setInt(2, t.getAccountID());
            ps2.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ----------------------------------------
    // FIND CUSTOMER BY ID
    // ----------------------------------------
    @Override
    public Customer findCustomerById(int id) {

        String sql = "SELECT * FROM customers WHERE customerID = ?";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new Customer(
                        rs.getInt("customerID"),
                        rs.getString("name"),
                        rs.getString("address"),
                        rs.getString("contact")
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    // ----------------------------------------
    // FIND ACCOUNT BY ID
    // ----------------------------------------
    @Override
    public Account findAccountById(int id) {

        String sql = "SELECT * FROM accounts WHERE accountID = ?";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new Account(
                        rs.getInt("accountID"),
                        rs.getInt("customerID"),
                        rs.getString("type"),
                        rs.getDouble("balance")
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    // ----------------------------------------
    // 🔥 FIND TRANSACTION BY ID (Missing earlier)
    // ----------------------------------------
    @Override
    public Transaction findTransactionById(int id) {

        String sql = "SELECT * FROM transactions WHERE transactionID = ?";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                Transaction t = new Transaction(
                        rs.getInt("accountID"),
                        rs.getString("type"),
                        rs.getDouble("amount")
                );

                t.setTransactionID(rs.getInt("transactionID"));
                return t;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    // ----------------------------------------
    // FIND BENEFICIARY BY ID
    // ----------------------------------------
    @Override
    public Beneficiary findBeneficiaryById(int id) {

        String sql = "SELECT * FROM beneficiaries WHERE beneficiaryID = ?";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new Beneficiary(
                        rs.getInt("beneficiaryID"),
                        rs.getInt("customerID"),
                        rs.getString("name"),
                        rs.getString("accountNumber"),
                        rs.getString("bankDetails")
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    // ----------------------------------------
    // GET ALL ACCOUNTS OF CUSTOMER
    // ----------------------------------------
    @Override
    public List<Account> getAccountsByCustomerId(int cid) {

        List<Account> list = new ArrayList<>();
        String sql = "SELECT * FROM accounts WHERE customerID = ?";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, cid);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                list.add(new Account(
                        rs.getInt("accountID"),
                        rs.getInt("customerID"),
                        rs.getString("type"),
                        rs.getDouble("balance")
                ));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    // ----------------------------------------
    // GET ALL TRANSACTIONS OF ACCOUNT
    // ----------------------------------------
    @Override
    public List<Transaction> getTransactionsByAccountId(int accId) {

        List<Transaction> list = new ArrayList<>();
        String sql = "SELECT * FROM transactions WHERE accountID = ?";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, accId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Transaction t = new Transaction(
                        rs.getInt("accountID"),
                        rs.getString("type"),
                        rs.getDouble("amount")
                );

                t.setTransactionID(rs.getInt("transactionID"));
                list.add(t);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    // ----------------------------------------
    // GET ALL BENEFICIARIES OF CUSTOMER
    // ----------------------------------------
    @Override
    public List<Beneficiary> getBeneficiariesByCustomerId(int cid) {

        List<Beneficiary> list = new ArrayList<>();
        String sql = "SELECT * FROM beneficiaries WHERE customerID = ?";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, cid);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                list.add(new Beneficiary(
                        rs.getInt("beneficiaryID"),
                        rs.getInt("customerID"),
                        rs.getString("name"),
                        rs.getString("accountNumber"),
                        rs.getString("bankDetails")
                ));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    // ----------------------------------------
    // GET ALL CUSTOMERS
    // ----------------------------------------
    @Override
    public Collection<Customer> getAllCustomers() {

        List<Customer> list = new ArrayList<>();
        String sql = "SELECT * FROM customers";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                list.add(new Customer(
                        rs.getInt("customerID"),
                        rs.getString("name"),
                        rs.getString("address"),
                        rs.getString("contact")
                ));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    // ----------------------------------------
    // GET ALL ACCOUNTS
    // ----------------------------------------
    @Override
    public Collection<Account> getAllAccounts() {

        List<Account> list = new ArrayList<>();
        String sql = "SELECT * FROM accounts";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                list.add(new Account(
                        rs.getInt("accountID"),
                        rs.getInt("customerID"),
                        rs.getString("type"),
                        rs.getDouble("balance")
                ));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    // ----------------------------------------
    // GET ALL TRANSACTIONS
    // ----------------------------------------
    @Override
    public Collection<Transaction> getAllTransactions() {

        List<Transaction> list = new ArrayList<>();
        String sql = "SELECT * FROM transactions";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Transaction t = new Transaction(
                        rs.getInt("accountID"),
                        rs.getString("type"),
                        rs.getDouble("amount")
                );

                t.setTransactionID(rs.getInt("transactionID"));
                list.add(t);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    // ----------------------------------------
    // GET ALL BENEFICIARIES
    // ----------------------------------------
    @Override
    public Collection<Beneficiary> getAllBeneficiaries() {

        List<Beneficiary> list = new ArrayList<>();
        String sql = "SELECT * FROM beneficiaries";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                list.add(new Beneficiary(
                        rs.getInt("beneficiaryID"),
                        rs.getInt("customerID"),
                        rs.getString("name"),
                        rs.getString("accountNumber"),
                        rs.getString("bankDetails")
                ));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
}
